package com.starknetwork.randomkit;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class KitListener implements Listener {

    private final RandomKitPlugin plugin;
    private final KitManager kits;
    // Players who already got their first-join kit (persisted in received.txt, one UUID per line).
    private final Set<UUID> received = ConcurrentHashMap.newKeySet();
    private final File receivedFile;

    public KitListener(RandomKitPlugin plugin, KitManager kits) {
        this.plugin = plugin;
        this.kits = kits;
        this.receivedFile = new File(plugin.getDataFolder(), "received.txt");
        loadReceived();
    }

    private void loadReceived() {
        if (!receivedFile.exists()) return;
        try {
            for (String line : Files.readAllLines(receivedFile.toPath(), StandardCharsets.UTF_8)) {
                line = line.trim();
                if (line.isEmpty()) continue;
                try { received.add(UUID.fromString(line)); } catch (IllegalArgumentException ignored) {}
            }
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not read received.txt: " + ex.getMessage());
        }
    }

    private void saveReceived(UUID id) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                Files.createDirectories(receivedFile.getParentFile().toPath());
                Files.writeString(receivedFile.toPath(), id + System.lineSeparator(), StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException ex) {
                plugin.getLogger().warning("Could not save received.txt: " + ex.getMessage());
            }
        });
    }

    // First join ever = kit once. After that, a new kit only comes after death (see onRespawn).
    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (!plugin.giveOnJoin || kits.size() == 0) return;
        if (received.contains(id)) return;

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline() || !received.add(id)) return;
            kits.giveRandom(p);
            saveReceived(id);
        }, 2L);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (!plugin.clearDropsOnDeath || kits.size() == 0) return;
        e.setKeepInventory(false);
        e.getDrops().clear();
        e.setKeepLevel(false);
        e.setDroppedExp(0);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent e) {
        if (!plugin.giveOnRespawn || kits.size() == 0) return;
        Player p = e.getPlayer();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) kits.giveRandom(p);
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        kits.forget(e.getPlayer());
    }

    // Preview GUI is read-only.
    // These fire on EVERY inventory click on the server, so they must be as cheap as possible.
    // getHolder(false) avoids Paper creating a block-state snapshot for chests/barrels/etc.
    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (e.getInventory().getHolder(false) instanceof KitCommand.PreviewHolder) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder(false) instanceof KitCommand.PreviewHolder) e.setCancelled(true);
    }
}
